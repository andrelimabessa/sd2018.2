class Cmutil:
    continua = True

    def menuEscolhaContinuaOuSalva(self):
        escolha = input("Escolha:\n(c) -- Continuar Jogando \n(s) -- Salvar e saia do jogo\n")
        return escolha