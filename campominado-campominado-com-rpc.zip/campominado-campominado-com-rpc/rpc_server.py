from datetime import datetime
from mensagemJogo import *
from campominado import *
from jsonrpclib.SimpleJSONRPCServer import SimpleJSONRPCServer

import json


ENCODE = "UTF-8"
MAX_BYTES = 65535
PORT = 5000            # Porta que o Servidor esta
HOST = '127.0.0.1'     	       # Endereco IP do Servidor

mensagensJogo = MensagemJogo()
campo = CampoMinado()



def logic_game(data_loaded):
    if(data_loaded['escolha'] == 'iniciaJogo'):
            print("Iniciando o jogo")
            
            mensagensJogo = MensagemJogo()
            campo.setaTamanhoCampoMinado()
            campo.inicializaMatriz()

            #Envia resposta

            data = {"idJogo":"jogodenis", "jogo":campo.getTabelaExibicao(), 'status':'continua', 'numJogadas':5}  
            return data	
        
    elif(data_loaded['escolha'] == 'continua'):
        print("jogo continuando")
        alive = campo.escolheArea(data_loaded['posx'],data_loaded['posy'])
        print("posicao escolhida: ", data_loaded['posx'] , data_loaded['posy'])
        
        if(campo.getJogadasRestantes() == 0):
            status= 'venceu'
        elif(alive):
            status = 'continua'
        else:
            status = 'gameover'

        data = {"idJogo":"jogodenis", "jogo":campo.getTabelaExibicao(), 'status':status, 'numJogadas': str(campo.getJogadasRestantes())} 
        return data	

    else:
        return "error"

def server():
    server = SimpleJSONRPCServer(('localhost', 8080))
    
    server.register_function(logic_game)
    server.serve_forever()