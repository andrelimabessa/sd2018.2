# campominado
-------------------

### Uma demonstração do clássico jogo **campo minado**

- Instruções para Iniciar o JOGO:
    - Certifique que tenha `python3` instalado em sua máquina
    - Para iniciar o jogo, execute no terminal: ` python3 main.py`
